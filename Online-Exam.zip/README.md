# Online-Exam-with-laravel

This a Laravel project on Online Exam (multiple choice). Course Teacher able to make question for registered student and give them UNIQUE exam code which will be automatic generate by System(app).Student can give exam against a UNIQUE code. Time limit,Instant Result,Question Review is available in this system.
