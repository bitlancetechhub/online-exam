<?php $__env->startSection('content'); ?>
<div>
    <div class="col-lg-offset-5">
        <h2>Id : <?php echo e($studentId); ?></h2>
        <h2>Course Name : <?php echo e($course); ?></h2>
        <h3 >Your total mark : <b><span style="color: green"><?php echo e($getScore); ?></span></b></h3>
    </div><hr>
            
        <?php $__currentLoopData = $answeredQuestion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answerQ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-8 col-sm-6 col-lg-offset-4">
                <h3><span style="color: red">Question : </span> <?php echo e($answerQ->question); ?> ?</h3>
                <div class="col-lg-offset-2">  
                    <div class="form-group">
                        <p type="text" name="given_answer">Your Choice Was : <?php echo e($answerQ->given_answer); ?></p>
                    </div>
                     <div class="form-group">
                        <p type="text" name="true_answer"><span style="color: green">True Answer : <?php echo e($answerQ->true_answer); ?></span></p>
                    </div>

                </div>
            </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>