<?php $__env->startSection('script'); ?>
<script type="text/javascript">

</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<body style="background-color: #63e9ab">
    <div class="container">
        <h2 style="text-align: center;">Review Question</strong></h2>
  		<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="">
                <form method="get" action="/makequestion/<?php echo e($question->id); ?>/edit" class="ansform">
                	<?php echo e(csrf_field()); ?>

                    <div class="">
                    	<!-- <p><?php echo e($question->id); ?></p> -->
                    	<input type="hidden" name="questionId" id="question" value="<?php echo e($question->id); ?>">

                        <input type="hidden" name="true_answer"  value="<?php echo e($question->answer); ?>">

                        <table class="table bg-success">
                          <tbody>
                            <div class="form-group">
                            <tr class="danger">
                              <td><strong>Question : </strong></td>
                              <td><input type="text" class="form-control" name="question" value="<?php echo e($question->question); ?>" readonly></td>

                            </tr>
                            </div>

                            <div class="form-group">
                            <tr class="bg-success">
                              <td><strong>Choice1 : </strong></td>
                              <td><input name="choice1" class="form-control"  value="<?php echo e($question->choice1); ?>" type="text" readonly></td>
                            </tr>
                          </div>

                          <div class="form-group">
                            <tr class="danger">
                              <td><strong>Choice2 : </strong></td>
                              <td><input name="choice2" class="form-control" value="<?php echo e($question->choice2); ?>" type="text" readonly></td>
                            </tr>
                          </div>

                          <div class="form-group">
                            <tr class="bg-success">
                              <td><strong>Choice3 : </strong></td>
                              <td><input name="choice3" class="form-control" value="<?php echo e($question->choice3); ?>" type="text" readonly></td>
                            </tr>
                          </div>

                          <div class="form-group">
                            <tr class="warning">
                              <td><strong>Choice4 : </strong></td>
                              <td><input name="choice4" class="form-control" value="<?php echo e($question->choice4); ?>" type="text" readonly></td>
                            </tr>
                          </div>

                          <div class="form-group">
                            <tr class="bg-success">
                              <td><strong>Answer : </strong></td>
                              <td><input name="answer" class="form-control" value="<?php echo e($question->answer); ?>" type="text" readonly></td>
                            </tr>
                          </div>
                          </tbody>
                        </table>
                    </div>
                    <button type="submit" name="submitFromEditPage" class="btn btn-warning btn-md edit_data  btn-lg align-center btn-block">Edit</button>
                 </form>
            </div><br>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






<a href="/"><button type="button" name="ReviewDone" class="btn btn-primary btn-block">Review Done</button></a><br><br>

</body>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>